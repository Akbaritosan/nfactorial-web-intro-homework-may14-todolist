import { Box, Checkbox, Divider, Text } from "@chakra-ui/react";

export function List({ title, children }) {
  return (
    <Box mt="64px">
      <Text fontWeight="bold" fontSize="34px" lineHeight="38px" color="#151517">
        {title}
      </Text>
      <Divider color="#151517" h="2px" my="24px" />
      {children}
    </Box>
  );
}
