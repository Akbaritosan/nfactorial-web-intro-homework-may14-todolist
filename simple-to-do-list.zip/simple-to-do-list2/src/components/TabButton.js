import { Box, Text } from "@chakra-ui/react";

export function TabButton({ title, isActive, onClick }) {
  return (
    <Box
      p="11px 24px"
      cursor="pointer"
      bgColor={isActive ? "#081E346B" : "#081E340D"}
      borderRadius="100px"
      onClick={onClick}
    >
      <Text
        fontWeight="bold"
        textStyle="sm"
        color={isActive ? "white" : "#081E34"}
      >
        {title}
      </Text>
    </Box>
  );
}
