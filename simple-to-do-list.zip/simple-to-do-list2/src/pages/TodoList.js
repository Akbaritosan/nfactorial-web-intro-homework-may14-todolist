import {
  Box,
  Checkbox,
  Circle,
  Flex,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Image,
  Text,
  Input,
  Textarea,
  Button,
} from "@chakra-ui/react";
import { TabButton } from "../components/TabButton";
import { useState } from "react";
import { List } from "../components/List";
import TrashIcon from "./Vector.png";
import LibIcon from "./Library.png";
import PlusIcon from "./Plus.png";

export function TodoList() {
  const [activeTab, setActiveTab] = useState("to-do");
  const [value, setValue] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [todoList, setTodoList] = useState([
    "Learn React",
    "Learn React Native",
    "Learn Redux",
    "Learn Redux Saga",
  ]);
  const [doneList, setDoneList] = useState([]);
  const [trashList, setTrashList] = useState([]);

  const onchange = (e) => {
    setValue(e.target.value);
  };

  const onOpen = () => {
    setIsOpen(true);
  };

  const onClose = () => {
    setIsOpen(false);
  };
  const addTask = () => {
    if (value) {
      setTodoList([...todoList, value]);
      setValue("");
      onClose();
    }
  };
  const handleMoveToDone = (taskIndex) => {
    const updatedTodoList = [...todoList];
    const movedTask = updatedTodoList.splice(taskIndex, 1);

    setTodoList(updatedTodoList);
    setDoneList([...doneList, movedTask]);
  };

  const handleMoveToTrashFromToDo = (taskIndex) => {
    const updatedTodoList = [...todoList];
    const movedTask = updatedTodoList.splice(taskIndex, 1);

    setTodoList(updatedTodoList);
    setTrashList([...trashList, movedTask]);
  };

  const handleMoveToToDoFromDone = (taskIndex) => {
    const updatedDoneList = [...doneList];
    const movedTask = updatedDoneList.splice(taskIndex, 1);

    setDoneList(updatedDoneList);
    setTodoList([...todoList, movedTask]);
  };

  const handleMoveToTrashFromDone = (taskIndex) => {
    const updatedDoneList = [...doneList];
    const movedTask = updatedDoneList.splice(taskIndex, 1);

    setDoneList(updatedDoneList);
    setTrashList([...trashList, movedTask]);
  };

  const handleMoveToToDoFromTrash = (taskIndex) => {
    const updatedTrashList = [...trashList];
    const movedTask = updatedTrashList.splice(taskIndex, 1);

    setTrashList(updatedTrashList);
    setTodoList([...todoList, movedTask]);
  };

  const changeActiveTab = (tab) => {
    setActiveTab(tab);
  };

  return (
    <Box px="80px" pt="100px">
      <Text fontWeight="bold" fontSize="34px" lineHeight="38px" color="#151517">
        Simple To Do List
      </Text>
      <Text fontWeight="medium" textStyle="md" color="#151517" mt="24px">
        Today is awesome day. The weather is awesome, you are awesome too!
      </Text>

      <Flex
        w="100%"
        justifyContent="space-between"
        mt="100px"
        alignItems="center"
      >
        <Flex gap="16px">
          <TabButton
            title="To Do"
            isActive={activeTab == "to-do"}
            onClick={() => changeActiveTab("to-do")}
          />
          <TabButton
            title="Done"
            isActive={activeTab == "done"}
            onClick={() => changeActiveTab("done")}
          />
          <TabButton
            title="Trash"
            isActive={activeTab == "trash"}
            onClick={() => changeActiveTab("trash")}
          />
        </Flex>
        <Menu
          closeOnSelect={false}
          isLazy={true}
          onClose={onClose}
          onOpen={onOpen}
          isOpen={isOpen}
        >
          <MenuButton>
            <Image src={PlusIcon} w="52px" h="52px" />
          </MenuButton>
          <MenuList
            bgColor="#E4E6E7"
            borderRadius="12px"
            boxShadow="0px 4px 4px rgba(0, 0, 0, 0.16)"
            p="12px"
          >
            <Flex flexDir="column" gap="10px">
              <Text ml="8px" fontWeight="medium" textStyle="md" color="#151517">
                Add New To Do
              </Text>
              <Textarea
                placeholder="Your text"
                w="236px"
                h="120px"
                borderRadius="8px"
                bgColor="white"
                border="none"
                resize="none"
                onChange={onchange}
              />
              <Button
                borderRadius="100px"
                bgColor="#081E34"
                p="11px 24px"
                fontWeight="bold"
                color="white"
                w="76px"
                _hover={{
                  bgColor: "#081E34",
                }}
                onClick={addTask}
              >
                Add
              </Button>
            </Flex>
          </MenuList>
        </Menu>
      </Flex>
      {activeTab === "to-do" && (
        <List title="To Do">
          {todoList.map((task, index) => (
            <Flex key={index} mb="16px" alignItems="center" gap="12px">
              <Menu>
                <MenuButton>
                  <Flex flexDir="column" gap="1px" w="4px" cursor="pointer">
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                  </Flex>
                </MenuButton>
                <MenuList
                  bgColor="#E4E6E7"
                  borderRadius="12px"
                  boxShadow="0px 4px 4px rgba(0, 0, 0, 0.16)"
                  p="12px"
                >
                  <MenuItem
                    p="0"
                    bgColor="#E4E6E7"
                    _hover={{
                      bgColor: "#E4E6E7",
                    }}
                    onClick={() => handleMoveToTrashFromDone(index)}
                  >
                    <Image
                      src={TrashIcon}
                      w="24px"
                      h="24px"
                      objectFit="contain"
                    />
                    <Text
                      ml="8px"
                      fontWeight="medium"
                      textStyle="md"
                      color="#151517"
                    >
                      {" "}
                      Move to Trash
                    </Text>
                  </MenuItem>
                </MenuList>
              </Menu>
              <Flex
                alignItems="center"
                onClick={() => handleMoveToDone(index)}
                cursor="Pointer"
                gap="12px"
              >
                <Checkbox colorScheme="purple" />
                <Text fontWeight="medium" textStyle="md" color="#151517">
                  {task}
                </Text>
              </Flex>
            </Flex>
          ))}
        </List>
      )}
      {activeTab === "done" && (
        <List title="Done">
          {doneList.map((task, index) => (
            <Flex key={index} mb="16px" alignItems="center" gap="12px">
              <Menu>
                <MenuButton>
                  <Flex flexDir="column" gap="1px" w="4px" cursor="pointer">
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                  </Flex>
                </MenuButton>
                <MenuList
                  bgColor="#E4E6E7"
                  borderRadius="12px"
                  boxShadow="0px 4px 4px rgba(0, 0, 0, 0.16)"
                  p="12px"
                >
                  <MenuItem
                    p="0"
                    bgColor="#E4E6E7"
                    _hover={{
                      bgColor: "#E4E6E7",
                    }}
                    onClick={() => handleMoveToTrashFromDone(index)}
                  >
                    <Image
                      src={TrashIcon}
                      w="24px"
                      h="24px"
                      objectFit="contain"
                    />
                    <Text
                      ml="8px"
                      fontWeight="medium"
                      textStyle="md"
                      color="#151517"
                    >
                      {" "}
                      Move to Trash
                    </Text>
                  </MenuItem>
                  <MenuItem
                    p="10px 0px 0px"
                    bgColor="#E4E6E7"
                    _hover={{
                      bgColor: "#E4E6E7",
                    }}
                    onClick={() => handleMoveToToDoFromDone(index)}
                  >
                    <Image
                      src={LibIcon}
                      w="24px"
                      h="24px"
                      objectFit="contain"
                    />
                    <Text
                      ml="9px"
                      fontWeight="medium"
                      textStyle="md"
                      color="#151517"
                    >
                      {" "}
                      Move Back to To Do
                    </Text>
                  </MenuItem>
                </MenuList>
              </Menu>
              <Flex
                alignItems="center"
                onClick={() => handleMoveToTrashFromDone(index)}
                cursor="Pointer"
                gap="12px"
              >
                <Checkbox defaultChecked colorScheme="purple" />
                <Text
                  fontWeight="medium"
                  textStyle="md"
                  color="#959595"
                  textDecoration="line-through"
                >
                  {task}
                </Text>
              </Flex>
            </Flex>
          ))}
        </List>
      )}
      {activeTab === "trash" && (
        <List title="Trash">
          {trashList.map((task, index) => (
            <Flex key={index} mb="16px" alignItems="center" gap="12px">
              <Menu>
                <MenuButton>
                  <Flex flexDir="column" gap="1px" w="4px" cursor="pointer">
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                    <Circle size="2.5px" bgColor="#AEAEAE" />
                  </Flex>
                </MenuButton>
                <MenuList
                  bgColor="#E4E6E7"
                  borderRadius="12px"
                  boxShadow="0px 4px 4px rgba(0, 0, 0, 0.16)"
                  p="12px"
                >
                  <MenuItem
                    p="10px 0px 0px"
                    bgColor="#E4E6E7"
                    _hover={{
                      bgColor: "#E4E6E7",
                    }}
                    onClick={() => handleMoveToToDoFromTrash(index)}
                  >
                    <Image
                      src={LibIcon}
                      w="24px"
                      h="24px"
                      objectFit="contain"
                    />
                    <Text
                      ml="9px"
                      fontWeight="medium"
                      textStyle="md"
                      color="#151517"
                    >
                      Move Back to To Do
                    </Text>
                  </MenuItem>
                </MenuList>
              </Menu>
              <Flex
                alignItems="center"
                onClick={() => handleMoveToToDoFromTrash(index)}
                cursor="Pointer"
                gap="12px"
              >
                <Checkbox defaultChecked colorScheme="purple" />
                <Text fontWeight="medium" textStyle="md" color="#151517">
                  {task}
                </Text>
              </Flex>
            </Flex>
          ))}
        </List>
      )}
      <Flex w="100%" justifyContent="space-between" my="42px">
        <Text textStyle="sm" fontWeight="medium" color="#081E34">
          Made with ❤️ at nFactorial in 2022.
        </Text>
        <Text textStyle="sm" fontWeight="medium" color="#081E34" opacity="0.5">
          Credits: icons from Icons8.
        </Text>
      </Flex>
    </Box>
  );
}
