import { ChakraProvider } from "@chakra-ui/react";
import "./App.css";
import { theme } from "@chakra-ui/react";
import { TodoList } from "./pages/TodoList";

function App() {
  return (
    <ChakraProvider theme={theme}>
      <TodoList />
    </ChakraProvider>
  );
}

export default App;
